require 'readline'
require 'forwardable'
require 'parking_lot/compound'
require 'parking_lot/vehicle'
require 'parking_lot/slot'
require 'parking_lot/notifier'

module ParkingLot

	def self.run(file_path=nil)
		@parking = Parking.new

		if file_path
			File.open(file_path).each do |line|
				@parking.perform(line)
			end
		else
			while line = Readline.readline("", true)
			  @parking.perform(line)
			end
		end
	end

	class Parking
		extend Forwardable
		attr_reader :command, :arguments, :compound

		def perform(input)
			@command = input.split[0]
			@arguments = input.split[1..-1]

			self.send(command, *arguments)
		rescue NoMethodError
			puts 'Command not found'
		end

		def create_parking_lot(capacity)
			@compound ||= Compound.new(capacity)
		end

		def park(registration_number, colour)
			compound.park(Vehicle.new(registration_number, colour))
		end

		def_delegators :compound, 
			:leave, 
			:status, 
			:registration_numbers_for_cars_with_colour,
			:slot_numbers_for_cars_with_colour,
			:slot_number_for_registration_number
	end
end
