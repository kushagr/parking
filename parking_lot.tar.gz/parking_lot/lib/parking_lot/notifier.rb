class ParkingLot::Notifier

	NOT_FOUND = "Not found"
	PARKING_FULL = "Sorry, parking lot is full"

	def populate_slots(compound)
		puts "Created a parking lot with #{compound.capacity} slots"
	end

	def park(compound, slot_number)
		puts "Allocated slot number: #{slot_number}"
	end

	def full?(compound)
		puts PARKING_FULL
	end

	def leave(compound, slot_number)
		puts "Slot number #{slot_number} is free"
	end

	def status(compound, status)
		puts status
	end

	def registration_numbers_for_cars_with_colour(compound, occupied_slots)
		unless occupied_slots.empty?
			puts occupied_slots.map(&:vehicle).map(&:registration_number).join(', ')
		else
			puts NOT_FOUND
		end
	end

	def slot_numbers_for_cars_with_colour(compound, occupied_slots)
		unless occupied_slots.empty?
			puts occupied_slots.map(&:slot_number).join(', ')
		else
			puts NOT_FOUND
		end
	end

	def slot_number_for_registration_number compound, occupied_slots
		unless occupied_slots.empty?
			puts occupied_slots.first.slot_number
		else
			puts NOT_FOUND
		end
	end
end