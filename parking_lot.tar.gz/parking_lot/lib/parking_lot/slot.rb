module ParkingLot
	class Slot
		attr_reader :slot_number
		attr_accessor :vehicle

		def initialize(slot_number, vehicle=nil)
			@slot_number = slot_number
			@vehicle = vehicle
		end

		def occupy(vehicle)
			self.vehicle = vehicle
		end

		def empty
			self.vehicle = nil
		end

		def empty?
			self.vehicle.nil?
		end

		def occupied?
			!empty?
		end

		def occupied_and_with_colour?(colour)
			occupied? && vehicle.matching_colour?(colour)
		end

		def occupied_and_with_registration_number?(registration_number)
			occupied? && vehicle.matching_registration_number?(registration_number)
		end

		def status
			"#{slot_number}           #{vehicle.details}\n" if occupied?
		end
	end
end