module ParkingLot
	class Vehicle
		attr_reader :registration_number, :colour

		def initialize(registration_number, colour)
			@registration_number = registration_number
			@colour = colour
		end

		def details
			"#{registration_number}      #{colour}"
		end

		def matching_colour?(colour)
			self.colour == colour
		end

		def matching_registration_number?(registration_number)
			self.registration_number == registration_number
		end
	end
end