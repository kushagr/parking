module ParkingLot
	class Compound
		attr_reader :capacity, :listeners
		attr_accessor :slots

		STATUS_HEADER = "Slot No.    Registration No    Colour\n" 

		def initialize(capacity=1, listener = Notifier.new)
			@capacity = capacity.to_i
			@slots = []
			add_listener(listener)
			populate_slots
		end

		def park(vehicle)
			if full?
				return nil
			end

			if slot = slots.find(&:empty?)
				slot.occupy vehicle
			end

			notify_listeners(__method__, slot.slot_number)
		end

		def leave(slot_number)
			slot = slots.find { |slot| slot.slot_number == slot_number.to_i }
			slot.empty

			notify_listeners(__method__, slot.slot_number)
		end

		def status
			status_text = slots.each_with_object(STATUS_HEADER) do |slot, status_text|
				status_text << slot.status if slot.status
			end
			
			notify_listeners(__method__, status_text)
		end

		def registration_numbers_for_cars_with_colour colour
			occupied_slots = slots.select { |slot| slot.occupied_and_with_colour?(colour) }

			notify_listeners(__method__, occupied_slots)
		end

		def slot_numbers_for_cars_with_colour colour
			occupied_slots = slots.select { |slot| slot.occupied_and_with_colour?(colour) }

			notify_listeners(__method__, occupied_slots)
		end

		def slot_number_for_registration_number registration_number
			occupied_slots = slots.select { |slot| slot.occupied_and_with_registration_number?(registration_number) }
			
			notify_listeners(__method__, occupied_slots)
		end

		def add_listener(listener)
	    (@listeners ||= []) << listener
	  end

	  def notify_listeners(event_name, *args)
      @listeners && @listeners.each do |listener|
        if listener.respond_to?(event_name)
          listener.public_send(event_name, self, *args)
        end
      end
    end

		def full?
			if slots.all? { |slot| slot.occupied? }
				notify_listeners(__method__)
				true
			else
				false
			end
		end

		private

		def populate_slots
			capacity.times do |index|
				slots << Slot.new(index+1)
			end
			notify_listeners(__method__)
		end
	end
end