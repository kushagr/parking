# Parking Lot

The Parking lot application helps automate the process of managing a parking lot.
Users of the application can park a car, make it leave a parking spot, get the current status of the parking lot and query the registration numbers and slot number based on colour and registration number of the vehicle.
it can be run using interactive shell and as well as take input from a file.

We do not support Windows at this point in time. If you don't have access to an OSX or Linux machine, we recommend setting up a Linux machine you can develop against using something like [VirtualBox](https://www.virtualbox.org/) or [Docker](https://docs.docker.com/docker-for-windows/#test-your-installation).

This needs [Ruby to be installed](https://www.ruby-lang.org/en/documentation/installation/), followed by some libraries. The steps are listed below.

## Setup

First, install [Ruby](https://www.ruby-lang.org/en/documentation/installation/). Then run the following commands under the `parking_lot` dir.
This installs the dependencies and runs the test suite to make sure everything is fine.

```
parking_lot $ ruby -v # confirm Ruby present
ruby 2.5.1p57 (2018-03-29 revision 63029) [x86_64-darwin17]
parking_lot $ bin/setup
Successfully installed bundler-1.16.1
Parsing documentation for bundler-1.16.1
Done installing documentation for bundler after 2 seconds
1 gem installed
Finished in 0.02475 seconds (files took 0.10997 seconds to load)
48 examples, 0 failures


```

## Usage

You can run the application from `parking_lot` by doing
```
parking_lot $ bin/parking_lot
```
This will be run in interactive mode and the user can type the various commands available


You can run the application using a file as well where each line will execute the commands supported
```
parking_lot $ bin/parking_lot file.txt
```

The various commands supported are
```
create_parking_lot 3 # creates a parking lot with the supplied capacity

park KA-123-122-0 White # parks the vehicle at the first empty slot

leave 1 # empties the first parking spot 

status # returns the current status of the parking lot

registration_numbers_for_cars_with_colour White # returns the registration numbers for the cars with the supplied colour

slot_numbers_for_cars_with_colour White # returns the slot numbers with the supplied colour

slot_number_for_registration_number KA-123-122-0 # returns the slot number of the car
```
