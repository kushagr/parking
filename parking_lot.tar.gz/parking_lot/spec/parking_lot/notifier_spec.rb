require 'spec_helper'

describe ParkingLot::Notifier do
	subject { ParkingLot::Notifier.new() }

	let(:compound) { double(:compound, capacity: 2, status: '1234') }

	describe '#populate_slot' do
		it 'prints the capacity details' do
			expect { subject.populate_slots(compound) }.to output("Created a parking lot with 2 slots\n").to_stdout
		end
	end

	describe '#park' do
		it 'prints the capacity details' do
			expect { subject.park(compound, 4) }.to output("Allocated slot number: 4\n").to_stdout
		end
	end

	describe '#full?' do
		it 'prints the capacity details' do
			expect { subject.full?(compound) }.to output("Sorry, parking lot is full\n").to_stdout
		end
	end

	describe '#leave' do
		it 'prints the capacity details' do
			expect { subject.leave(compound, 3) }.to output("Slot number 3 is free\n").to_stdout
		end
	end

	describe '#status' do
		it 'prints the capacity details' do
			expect { subject.status(compound, compound.status) }.to output("1234\n").to_stdout
		end
	end

	describe '#registration_numbers_for_cars_with_colour' do
		let(:slot) { double(:slot, vehicle: double(:vehicle, registration_number: 1234)) }

		context 'when slot are occupied' do
			it 'prints the capacity details' do
				expect { subject.registration_numbers_for_cars_with_colour(compound, [slot, slot]) }.to output("1234, 1234\n").to_stdout
			end
		end

		context 'when slot are not occupied' do
			it 'prints the capacity details' do
				expect { subject.registration_numbers_for_cars_with_colour(compound, []) }.to output("Not found\n").to_stdout
			end
		end
	end

	describe '#slot_numbers_for_cars_with_colour' do
		let(:slot) { double(:slot, slot_number: 1234) }

		context 'when slot are occupied' do
			it 'prints the capacity details' do
				expect { subject.slot_numbers_for_cars_with_colour(compound, [slot, slot]) }.to output("1234, 1234\n").to_stdout
			end
		end

		context 'when slot are not occupied' do
			it 'prints the capacity details' do
				expect { subject.slot_numbers_for_cars_with_colour(compound, []) }.to output("Not found\n").to_stdout
			end
		end
	end

	describe '#slot_number_for_registration_number' do
		let(:slot) { double(:slot, slot_number: 1234) }

		context 'when slot are occupied' do
			it 'prints the capacity details' do
				expect { subject.slot_number_for_registration_number(compound, [slot, slot]) }.to output("1234\n").to_stdout
			end
		end

		context 'when slot are not occupied' do
			it 'prints the capacity details' do
				expect { subject.slot_number_for_registration_number(compound, []) }.to output("Not found\n").to_stdout
			end
		end
	end
end