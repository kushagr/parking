require 'spec_helper'

describe ParkingLot::Slot do
	subject { described_class.new(1) }

	describe '#occupy' do
		let(:vehicle) { double(:vehicle) }

		it 'occupies the slot number with the vehicle' do
			expect(subject.vehicle).to be_nil
			subject.occupy(vehicle)
			expect(subject.vehicle).to eq vehicle
		end
	end

	describe '#empty' do
		let(:vehicle) { double(:vehicle) }

		it 'occupies the slot number with the vehicle' do
			subject.occupy(vehicle)
			subject.empty
			expect(subject.vehicle).to eq nil
		end
	end

	describe '#occupied?' do
		let(:vehicle) { double(:vehicle) }

		context 'when slot is empty' do
			it 'returns false' do
				expect(subject.occupied?).to eq false
			end
		end

		context 'when slot is occupied' do
			it 'returns true' do
				subject.occupy(vehicle)

				expect(subject.occupied?).to eq true
			end
		end
	end

	describe '#empty?' do
		let(:vehicle) { double(:vehicle) }

		context 'when slot is empty' do
			it 'returns false' do
				expect(subject.empty?).to eq true
			end
		end

		context 'when slot is occupied' do
			it 'returns true' do
				subject.occupy(vehicle)

				expect(subject.empty?).to eq false
			end
		end
	end

	describe 'status' do
		let(:vehicle) { ParkingLot::Vehicle.new('KA-01-HH-1234', 'White') }

		context 'when slot is empty' do
			it 'returns nil' do
				expect(subject.status).to eq nil
			end
		end

		context 'when slot is empty' do
			it 'returns the status' do
				subject.occupy vehicle
				expect(subject.status).to eq "1           KA-01-HH-1234      White\n"
			end
		end
	end

	describe '#occupied_and_with_colour' do
		let(:vehicle) { ParkingLot::Vehicle.new('KA-01-HH-1234', 'White') }

		context 'when occupied and vehicle with matching colour' do
			before do
				subject.occupy vehicle
			end

			it 'returns true' do
				expect(subject.occupied_and_with_colour?('White')).to eq true
			end
		end

		context 'when occupied and vehicle with not matching colour' do
			before do
				subject.occupy vehicle
			end

			it 'returns true' do
				expect(subject.occupied_and_with_colour?('Black')).to eq false
			end
		end

		context 'when not occupied' do
			it 'returns true' do
				expect(subject.occupied_and_with_colour?('White')).to eq false
			end
		end
	end

	describe '#occupied_and_with_registration_number' do
		let(:vehicle) { ParkingLot::Vehicle.new('KA-01-HH-1234', 'White') }

		context 'when occupied and vehicle with matching registration_number' do
			before do
				subject.occupy vehicle
			end

			it 'returns true' do
				expect(subject.occupied_and_with_registration_number?('KA-01-HH-1234')).to eq true
			end
		end

		context 'when occupied and vehicle with not matching registration_number' do
			before do
				subject.occupy vehicle
			end

			it 'returns true' do
				expect(subject.occupied_and_with_registration_number?('KA-01-HH-1235')).to eq false
			end
		end

		context 'when not occupied' do
			it 'returns true' do
				expect(subject.occupied_and_with_registration_number?('KA-01-HH-1234')).to eq false
			end
		end
	end
end