require 'spec_helper'

describe ParkingLot::Parking do 

	subject { described_class.new }

	describe 'perform' do
		context 'when command exists' do
			it 'performs the steps outlined in the arguments' do
				compound = subject.perform('create_parking_lot 3')
				expect(compound.capacity).to eq 3
			end
		end

		context 'when command does not exist' do
			it 'should return command not found' do
				expect{ subject.perform('something else') }.to output("Command not found\n").to_stdout
			end
		end
	end
end