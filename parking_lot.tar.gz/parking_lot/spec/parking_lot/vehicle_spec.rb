require 'spec_helper'

describe ParkingLot::Vehicle do
	subject { described_class.new('KA 00101', 'Black') }

	describe '.new' do
		it 'sets the registration_number' do
			expect(subject.registration_number).to eq 'KA 00101'
		end

		it 'sets the colour' do
			expect(subject.colour).to eq 'Black'
		end
	end

	describe '#matching_colour?' do
		context 'when colours match' do
			it 'returns true' do
				expect(subject.matching_colour?('Black')).to eq true
			end
		end

		context 'when colours do not match' do
			it 'returns false' do
				expect(subject.matching_colour?('White')).to eq false
			end
		end
	end

	describe '#matching_registration_number?' do
		context 'when registration_numbers match' do
			it 'returns true' do
				expect(subject.matching_registration_number?('KA 00101')).to eq true
			end
		end

		context 'when registration_numbers do not match' do
			it 'returns false' do
				expect(subject.matching_registration_number?('KA 00102')).to eq false
			end
		end
	end
end