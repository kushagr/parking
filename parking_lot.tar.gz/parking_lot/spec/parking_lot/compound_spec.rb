require 'spec_helper'

describe ParkingLot::Compound do
	subject { described_class.new() }

	describe '.new' do

		context 'when capacity is supplied' do
			subject { described_class.new(capacity) }

			let(:capacity) { 5 }

			it 'creates the parking_lot with supplied capacity' do
				expect(subject.capacity).to eq 5
			end
		end

		context 'when capacity is not supplied' do
			it 'creates the parking_lot with supplied capacity' do
				expect(subject.capacity).to eq 1
			end
		end
	end

	describe '#park' do
		let(:vehicle) { double(:vehicle) }

		context 'when compund is full' do
			before do
				subject.park(vehicle)
			end

			it 'parks the vehicle in the first slot' do
				expect { subject.park(vehicle) }.to change(subject.slots, :count).by(0)
			end

			it 'prints the capacity full message' do
				expect { subject.park(vehicle) }.to output("Sorry, parking lot is full\n").to_stdout
			end
		end

		context 'when slots are empty' do
			it 'parks the vehicle in the first slot' do
				subject.park(vehicle)
				expect(subject.slots.first).to_not be_empty
			end
		end

		context 'when an empty slot exists in the middle' do

			let(:slot) { ParkingLot::Slot.new(1, vehicle) }
			let(:empty_slot) { ParkingLot::Slot.new(2) }
			let(:other_slot) { ParkingLot::Slot.new(3, vehicle) }

			before do
				subject.slots = [slot, empty_slot, other_slot]
			end

			it 'parks the vehicle in the first empty slot' do
				subject.park(vehicle)
				expect(empty_slot).to_not be_empty
			end

			it 'prints the allocated spot details' do
				expect { subject.park(vehicle) }.to output("Allocated slot number: 2\n").to_stdout
			end
		end
	end

	describe '#leave' do
		let(:vehicle) { double(:vehicle) }
		let(:slot) { ParkingLot::Slot.new(1, vehicle) }
		let(:other_slot) { ParkingLot::Slot.new(2, vehicle) }

		before do
			subject.slots = [slot, other_slot]
		end

		it 'marks the slot as empty' do
			subject.leave(1)
			expect(subject.slots.first.empty?).to eq true
		end

		it 'prints the emptied spot details' do
			expect { subject.leave(2) }.to output("Slot number 2 is free\n").to_stdout
		end
	end

	describe '#status' do
		let(:vehicle) { ParkingLot::Vehicle.new 'KA-01-HH-1234', 'White' }
		let(:other_vehicle) { ParkingLot::Vehicle.new 'KA-01-HH-2234', 'Black' }

		let(:slot) { ParkingLot::Slot.new(1, vehicle) }
		let(:empty_slot) { ParkingLot::Slot.new(2) }
		let(:other_slot) { ParkingLot::Slot.new(3, other_vehicle) }

		before do
			subject.slots = [slot, empty_slot, other_slot]
		end

		let(:expected) {
			"Slot No.    Registration No    Colour\n1           KA-01-HH-1234      White\n3           KA-01-HH-2234      Black\n"
		}

		it 'returns the status' do
			expect{ subject.status }.to output(expected).to_stdout
		end
	end

	describe '#registration_numbers_for_cars_with_colour' do
		let(:vehicle) { ParkingLot::Vehicle.new 'KA-01-HH-1234', 'White' }
		let(:other_vehicle) { ParkingLot::Vehicle.new 'KA-01-HH-2234', 'Black' }
		let(:another_vehicle) { ParkingLot::Vehicle.new 'DL-01-HH-2234', 'White' }


		let(:slot) { ParkingLot::Slot.new(1, vehicle) }
		let(:other_slot) { ParkingLot::Slot.new(2, other_vehicle) }
		let(:another_slot) { ParkingLot::Slot.new(3, another_vehicle) }

		before do
			subject.slots = [slot, other_slot, another_slot]
		end

		it 'returns the registration numbers for cars with colour' do
			expect{
				subject.registration_numbers_for_cars_with_colour('White')
			}.to output("KA-01-HH-1234, DL-01-HH-2234\n").to_stdout
		end
	end

	describe '#slot_numbers_for_cars_with_colour' do
		let(:vehicle) { ParkingLot::Vehicle.new 'KA-01-HH-1234', 'White' }
		let(:other_vehicle) { ParkingLot::Vehicle.new 'KA-01-HH-2234', 'Black' }
		let(:another_vehicle) { ParkingLot::Vehicle.new 'DL-01-HH-2234', 'White' }


		let(:slot) { ParkingLot::Slot.new(1, vehicle) }
		let(:other_slot) { ParkingLot::Slot.new(2, other_vehicle) }
		let(:another_slot) { ParkingLot::Slot.new(3, another_vehicle) }

		before do
			subject.slots = [slot, other_slot, another_slot]
		end

		it 'returns the slot numbers for cars with colour' do
			expect{
				subject.slot_numbers_for_cars_with_colour('White')
			}.to output("1, 3\n").to_stdout
		end
	end

	describe '#slot_number_for_registration_number' do
		let(:vehicle) { ParkingLot::Vehicle.new 'KA-01-HH-1234', 'White' }

		let(:slot) { ParkingLot::Slot.new(1, vehicle) }

		before do
			subject.slots = [slot]
		end

		context 'when vehicle exists' do
			it 'returns the slot number' do
				expect{ subject.slot_number_for_registration_number('KA-01-HH-1234')}.to output("1\n").to_stdout
			end
		end
	end

	describe '#add_listener' do
		let(:notifier) { double(:notifier) }
		
		it 'adds listeners to the list' do
			subject.add_listener(notifier)
			expect(subject.listeners).to include(notifier)
		end
	end

	describe '#notify_listener' do
		let(:notifier) { double(:notifier, populate_slot: 'Slot populated') }
		
		it 'adds listeners to the list' do
			expect(notifier).to receive(:populate_slot) { 'Slot populated' }
			subject.add_listener(notifier)
			subject.notify_listeners(:populate_slot)
		end
	end
end